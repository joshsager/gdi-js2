

function hardway(){
  document.getElementById("albums").innerHTML = "<h1>Joshua</h1>";
  document.getElementById("albums").innerHTML = "<h2>Sager</h2>";
}
